// ConsoleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MathLibrary.h"
#include <iostream>

using namespace Math;

int main()
{
	int n;
	std::cout << "Enter size of matrix : " << std::endl;
	std::cin >> n;

	int ** matrix = AllocateMemory(n);

	InitMatrix(matrix, n);

	std::cout << std::endl;
	DisplayMatrix(matrix, n);
	std::cout << std::endl;

	int ** newmatrix = AllocateMemory(n);

	CreateNewMatrix(matrix, newmatrix, n);

	std::cout << std::endl;
	DisplayMatrix(newmatrix, n);
	std::cout << std::endl;

	FreeMemory(matrix, n);
	FreeMemory(newmatrix, n);

	system("pause");
    return 0;
}

