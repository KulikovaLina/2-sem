// MathLibrary.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "MathLibrary.h"
#include <iostream>
#include <stdexcept>

MATHLIBRARY_API int ** Math::AllocateMemory(int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	int ** a = new int*[n];

	for (int i = 0; i < n; i++)
	{
		a[i] = new int[n];
	}

	return a;
}

MATHLIBRARY_API void Math::InitMatrix(int ** const matrix, int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			matrix[i][j] = rand() % 10 - 5;
		}
	}

}

MATHLIBRARY_API void Math::DisplayMatrix(int ** const matrix, int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			std::cout.width(5);
			std::cout << matrix[i][j] << "  ";
		}

		std::cout << std::endl;
	}
}

MATHLIBRARY_API void Math::CreateNewMatrix(int ** const matrix, int ** const newmatrix, int n )
{
	for (int p = 0; p < n; p++)
	{
		for (int t = 0; t < n; t++)
		{
			int k = t;
			int max = matrix[p][t];

			for (int i = p; i < n; i++)
			{
				for (int j = k; j < n; j++)
				{
					if (max < matrix[i][j])
					{
						max = matrix[i][j];
					}
				}
				k++;
			}

			k = t;
			for (int i = p - 1; i >= 0; i--)
			{  
				k++;
				for (int j = k; j < n; j++)
				{
					if (max < matrix[i][j])
					{
						max = matrix[i][j];
					}
				}
			}
			
			newmatrix[p][t] = max;
		}
	}
}

MATHLIBRARY_API void Math::FreeMemory(int ** const matrix, int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		delete[] matrix[i];
	}

	delete[] matrix;
}
