#pragma once

#ifdef MathLibrary_EXPORTS
#define MATHLIBRARY_API __declspec(dllexport) 
#else
#define MATHLIBRARY_API __declspec(dllimport) 
#endif

namespace Math
{
	MATHLIBRARY_API int ** AllocateMemory(int);
	MATHLIBRARY_API void InitMatrix(int ** const, int);
	MATHLIBRARY_API void DisplayMatrix(int ** const, int);
	MATHLIBRARY_API void CreateNewMatrix(int ** const, int ** const, int);
	MATHLIBRARY_API void FreeMemory(int ** const, int);
}