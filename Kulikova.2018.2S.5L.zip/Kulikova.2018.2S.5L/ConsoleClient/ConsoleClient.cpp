// ConsoleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "StringLibrary.h"
#include <iostream>

using namespace String;

int main()
{
	const int LENGTH = 256;
	char source[LENGTH];
	std::cout << "Enter your string : " << std::endl;
	std::cin >> source;
	std::cin.getline(source, LENGTH, '\n');

	int n = 0;

	char ** arrayOfWords = ObtainWords(source, n);

	std::cout << std::endl;
	DisplayWords(arrayOfWords, n);
	std::cout << std::endl;

	char ** newarrayOfWords;
	int m = 0;

	FindWords(arrayOfWords, newarrayOfWords, n, m);

	std::cout << std::endl;
	DisplayWords(newarrayOfWords, m);
	std::cout << std::endl;

	system("pause");
    return 0;
}

