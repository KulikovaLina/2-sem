// StringLibrary.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "StringLibrary.h"
#include <string.h>
#include <iostream>
#include <stdexcept>

STRINGLIBRARY_API char ** String::ObtainWords(char * source, int & n)
{
	char * copy = new char[strlen(source) + 1];

	if (copy == nullptr)
	{
		throw std::bad_alloc();
	}

	strcpy(copy, source);
	char ** words = new char*[strlen(copy) / 2];

	if(words == nullptr)
	{
		throw std::bad_alloc();
	}

	n = 0;
	char * symbols = "      1234567890-=!@#$%^&*()_+{}|[];:'<>?/.,\x22 ";
	char * pword = strtok(copy, symbols);
	words[n] = new char[strlen(pword) + 1];

	if (words[n] == nullptr)
	{
		throw std::bad_alloc();
	}

	strcpy(words[n], pword);
	n++;

	while (pword)
	{
		pword = strtok('\0', symbols);

		if (pword)
		{
			words[n] = new char[strlen(pword) + 1];

			if (words[n] == nullptr)
			{
				throw std::bad_alloc();
			}

			strcpy(words[n], pword);
			n++;
		}
	}

	delete[] copy;
	return words;
}

STRINGLIBRARY_API void String::DisplayWords(char ** words, int n)
{
	for (int i = 0; i < n; i++)
	{
		std::cout << words[i] << std::endl;
	}
}

STRINGLIBRARY_API bool String::ComparisonOfString(char ** newwords, char ** words, int index, int m)
{
	for (int i = 0; i < m; i++)
	{
		if (strcmp(words[index], newwords[i]) == 0)
		{
			return 0;
		}
	}

	return 1;
}


STRINGLIBRARY_API void String::FindWords(char ** words, char ** newwords, int n, int& m)
{
	int i = 0;

	while(words[i][0] != words[i][strlen(words[i]) - 1])
	{
		i++;
	}

	int j = 0;
	newwords[j] = words[i];
	i++;
	m++;

	for (j = 1; j < n; j++)
	{
		if (words[i][0] == words[i][strlen(words[i]) - 1] && ComparisonOfString(newwords, words, i, m) != 0)
		{
			newwords[j] = words[i];
			m++;
		}
		i++;
	}
}

