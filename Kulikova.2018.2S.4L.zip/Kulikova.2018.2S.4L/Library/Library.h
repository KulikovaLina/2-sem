#pragma once

#ifdef Library_EXPORTS
#define LIBRARY_API __declspec(dllexport) 
#else
#define LIBRARY_API __declspec(dllimport) 
#endif

namespace Math
{
	LIBRARY_API int * AllocateMemory(int);
	LIBRARY_API void InitArray(int * const, int);
	LIBRARY_API void DisplayArray(int * const, int);
	LIBRARY_API int ** AllocateMemory(int, int * const);
	LIBRARY_API void InitMatrix(int ** const, int, int * const);
	LIBRARY_API void DisplayMatrix(int ** const, int, int * const); 
	LIBRARY_API void DifferenceOfMatrix(int ** const, int ** const, int, int * const);
	LIBRARY_API void FreeMemory(int ** const, int);
}
