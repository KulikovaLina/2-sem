// Library.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "Library.h"
#include <iostream>
#include<stdexcept>

LIBRARY_API int * Math::AllocateMemory(int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	int * array = new int[n];

	if (array == nullptr)
	{
		throw std::bad_alloc();
	}

	return array;
}

LIBRARY_API void Math::InitArray(int * const array, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int i = 0, j = 0; i < n; i++)
	{
		array[i] = ++j;
	}
}

LIBRARY_API void Math::DisplayArray(int * const array, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int i = 0; i < n; i++)
	{
		std::cout << array[i] << "  ";
	}
}

LIBRARY_API int ** Math::AllocateMemory(int n, int * const m)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension can not be less or equal zero!");
	}

	if (m == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	int ** matrix = new int*[n];

	for (int i = 0; i < n; i++)
	{
		matrix[i] = new int[m[i]];
	}

	return matrix;
}

LIBRARY_API void Math::InitMatrix(int ** const matrix, int n, int * const m)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension can not be less or equal zero!");
	}

	if (m == nullptr || matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m[i]; j++)
		{
			matrix[i][j] = rand() % 10 - 5;
		}
	}
}

LIBRARY_API void Math::DisplayMatrix(int ** const matrix, int n, int * const m)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension can not be less or equal zero!");
	}

	if (m == nullptr || matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m[i]; j++)
		{
			std::cout.width(4);
			std::cout << matrix[i][j];
		}
		for (int j = i + 1; j < n; j++)
		{
			std::cout.width(4);
			std::cout << matrix[j][i];
		}
		std::cout << std::endl;
	}
}

LIBRARY_API void Math::DifferenceOfMatrix(int ** const matrixA, int ** const matrixB, int n, int * const m)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension can not be less or equal zero!");
	}

	if (m == nullptr || matrixA == nullptr || matrixB == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m[i]; j++)
		{
			matrixA[i][j] -= matrixB[i][j];
		}
	}
}

LIBRARY_API void Math::FreeMemory(int ** const matrix, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		delete[] matrix[i];
	}

	delete[] matrix;
}
