// ConsoleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Library.h"
#include <iostream>

using namespace Math;

int main()
{
	int n;
	std::cout << "Enter size of matrix : " << std::endl;
	std::cin >> n;

	int * m = AllocateMemory(n);

	InitArray(m, n);

	DisplayArray(m, n);

	int ** matrixA = AllocateMemory(n, m);

	InitMatrix(matrixA, n, m);

	std::cout << std::endl;
	std::cout << std::endl;
	DisplayMatrix(matrixA, n, m);
	std::cout << std::endl;

	int ** matrixB = AllocateMemory(n, m);

	InitMatrix(matrixB, n, m);

	std::cout << std::endl;
	std::cout << std::endl;
	DisplayMatrix(matrixB, n, m);
	std::cout << std::endl;

	DifferenceOfMatrix(matrixA, matrixB, n, m);

	std::cout << std::endl;
	std::cout << std::endl;
	DisplayMatrix(matrixA, n, m);
	std::cout << std::endl;

	FreeMemory(matrixA, n);
	FreeMemory(matrixB, n);

	system("pause");
	return 0;
}

