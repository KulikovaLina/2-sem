// ConsoleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "MathLibrary.h"
#include <iostream>

using namespace Math;

int main()
{
	/* int a = 10;

	 int aarray[10] = { 2, 6, 5, 67, 35, 66, 45, 75, 34, 56 };

	DisplayArray(aarray, a);
	std::cout << std::endl;

	int amin = FindMinElement(aarray, a);
	std::cout << amin << std::endl;

	int b = a;
	int newaarray[10];

	CreateNewArray(aarray, a, newaarray, b, amin);

	DisplayArray(aarray, a);
	std::cout << std::endl;
	DisplayArray(newaarray, b);
	std::cout << std::endl;

	BubbleSort(newaarray, b);

	DisplayArray(newaarray, b);
	std::cout << std::endl;
	std::cout << std::endl;*/


	int n;
	std::cout << "Enter size of array: " << std::endl;
	std::cin >> n;

	int * array = AllocateMemory(n);

	InitArray(array, n);

	DisplayArray(array, n);
	std::cout << std::endl;

	int min = FindMinElement(array, n);
	std::cout << min << std::endl;

	int k = n;
	int * newarray = AllocateMemory(k);

	CreateNewArray(array, n, newarray, k, min);

	DisplayArray(array, n);
	std::cout << std::endl;
	DisplayArray(newarray, k);
	std::cout << std::endl;

	BubbleSort(newarray, k);

	DisplayArray(newarray, k);
	std::cout << std::endl;

	FreeMemory(array);
	FreeMemory(newarray);

	system("pause");
	return 0;
}





