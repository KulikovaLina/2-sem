// MathLibrary.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "MathLibrary.h"
#include <stdexcept>
#include <iostream>

MATHLIBRARY_API int * Math::AllocateMemory(int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	int * array = new int[n];

	if (array == nullptr)
	{
		throw std::bad_alloc();
	}

	return array;
}

MATHLIBRARY_API void Math::InitArray(int * const array, int n)
{
    if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int * p = array; p < array + n; p++)
	{
		*p = rand() % 100 - 50;
	}
}

MATHLIBRARY_API void Math::DisplayArray(int * const array, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	for (int * p = array; p < array + n; p++)
	{
		std::cout << *p << " ";
	}
}

MATHLIBRARY_API int Math::FindMinElement(int * const array, int n)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}
	
	int i = 0;
	
	while (array[i] == 0 && i < n)
	{
		i++;
	}

	int min = array[i];

	for (int j = 0; j < n; j++)
	{
		if (array[j] < min && array[j] != 0)
		{
			min = array[j];
		}
	}

	return min;
}

MATHLIBRARY_API void Math::RemoveElement(int * const array, int& n, int index)
{
	if (n <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	if (index < 0 || index > n)
	{
		throw std::out_of_range("Position of array must be more than zero and less than size!");
	}

	for (int i = index; i < n - 1; i++)
	{
		array[i] = array[i + 1];
	}

	n--;
}

MATHLIBRARY_API void Math::CreateNewArray(int * const array, int& n, int * const newarray, int& k, int min)
{
	if (n <= 0 || k <= 0)
	{
		throw std::out_of_range("Dimension must be more than zero!");
	}

	if (array == nullptr || newarray == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	int j = 0;

	for (int i = 0; i < n - 1; i++)
	{
		if (array[i] % min == 0)
		{
			newarray[j] = array[i + 1];
			
			RemoveElement(array, n, i + 1);

		    j++;
		}
	}
	
	k = j;
}

MATHLIBRARY_API void Math::FreeMemory(int * const array)
{
	if (array == nullptr)
	{
		throw std::invalid_argument("Argument is null!");
	}

	delete[] array;
}

MATHLIBRARY_API int Math::BinaryRepresentation(int value)
{
	int counter = 0;
	
		while (value)
		{
			if (value % 2 != 0)
			{
				counter++;
			}

			value /= 2;

			if (value == 1)
			{
				counter++;
				break;
			}
		}

	return counter;
}

MATHLIBRARY_API void Math::Swap(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

MATHLIBRARY_API void Math::BubbleSort(int * const array, int n)
{
	for(int j = 0; j < n; j++)
	{
		for (int i = 0; i < n - 1; i++)
		{
			if (BinaryRepresentation(array[i]) > BinaryRepresentation(array[i + 1]))
			{
				Swap(array[i], array[i + 1]);
			}
		}
	}
}

