#pragma once

#ifdef MathLibrary_EXPORTS
#define MATHLIBRARY_API __declspec(dllexport) 
#else
#define MATHLIBRARY_API __declspec(dllimport) 
#endif

namespace Math
{
	MATHLIBRARY_API double ** AllocateMemory(int);
	MATHLIBRARY_API double SinTaylor(double, double);
	MATHLIBRARY_API double CosTaylor(double, double);
	MATHLIBRARY_API void InitMatrixA(double ** const, int, double);
	MATHLIBRARY_API void DisplayMatrix(double ** const, int);
	MATHLIBRARY_API void InitMatrixB(double ** const, int);
	MATHLIBRARY_API void FreeMemory(double ** const, int);
}