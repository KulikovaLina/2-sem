// MathLibrary.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "MathLibrary.h"
#include <stdexcept>
#include <iostream>
#include <cmath>

MATHLIBRARY_API double ** Math::AllocateMemory(int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	double ** a = new double*[n];

	for (int i = 0; i < n; i++)
	{
		a[i] = new double[n];
	}

	return a;
}

MATHLIBRARY_API double Math::SinTaylor(double value, double accurancy)
{
	if (accurancy < 0.0 || accurancy >= 1.0)
	{
		throw std::out_of_range("Accurancy must be between 0 and 1!");
	}

	double temp = value, sum = 0;

	for (int i = 1; fabs(temp) > accurancy; i++)
	{
		sum += temp;
		temp = temp * value * value / (2 * i) / (2 * i + 1);
	}

	return sum;
}

MATHLIBRARY_API double Math::CosTaylor(double value, double accurancy)
{
	if (accurancy < 0.0 || accurancy >= 1)
	{
		throw std::invalid_argument("Dimension must be between 0 and 1!");
	}

	double temp = 1, sum = 1;

	for (int i = 1; fabs(temp) > accurancy; i++)
	{
		temp = temp * value * value / 2 / i / (2 * i + 1);
		sum += temp;
	}

	return sum;
}

MATHLIBRARY_API void Math::InitMatrixA(double ** const matrix, int n, double accurancy)
{
	if(n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (i == j)
				matrix[i][j] = i + j;
			else
				matrix[i][j] = (2 * CosTaylor(2 * i, accurancy) - SinTaylor(2 * j, accurancy)) / (i + 1) / (i + 1);
		}
	}
}

MATHLIBRARY_API void Math::DisplayMatrix(double ** const matrix, int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			std::cout.width(4);
			std::cout << matrix[i][j] << "  ";
		}

		std::cout << std::endl;
	}
}

MATHLIBRARY_API void Math::InitMatrixB(double ** const matrix, int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrix == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (i == j)
				matrix[i][j] = i + j;
			else
				matrix[i][j] = (2 * cos(2 * i) - sin(2 * j)) / (i + 1) / (i + 1);
		}
	}
}

MATHLIBRARY_API void Math::CompareMatrix(double ** const matrixA, double ** const matrixB, double ** const comparison, int n)
{
	if (n <= 0)
	{
		throw std::invalid_argument("Dimension can not be less or equal zero!");
	}

	if (matrixA == nullptr || matrixB == nullptr)
	{
		throw std::invalid_argument("Pointer can not be null!");
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			comparison[i][j] = matrixA[i][j] - matrixB[i][j];
		}
	}
}

