#include "stdafx.h"
#include "CppUnitTest.h"
#include "MathLibrary.h"
#include <cmath>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;
using namespace Math;

namespace MathLibraryTests
{		
	TEST_CLASS(MathLibraryTests)
	{
	public:
		
		TEST_METHOD(SinTaylor_1)
		{
			double tolerance = 0.001;
			double x = 0.127;
			double expected = sin(x);

			double actual = SinTaylor(x, tolerance);

			Assert::IsTrue(fabs(expected - actual) < tolerance);
		}

		TEST_METHOD(CosTaylor_1)
		{
			double tolerance = 0.1;
			double x = 0.127;
			double expected = cos(x);

			double actual = CosTaylor(x, tolerance);

			Assert::IsTrue(fabs(expected - actual) < tolerance);
		}

	};
}