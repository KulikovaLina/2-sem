// ConsoleClient.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "MathLibrary.h"

using namespace Math;

int main()
{
	int n;
	std::cout << "Enter size of matrix : " << std::endl;
	std::cin >> n;

	double ** matrixA = AllocateMemory(n);

	double accurancy;
	while (true)
	{
		std::cout << "Enter 0 <= accurancy < 1 : " << std::endl;
		std::cin >> accurancy;
		if (accurancy >= 0 && accurancy < 1)
			break;
		else
			std::cout << "Error! Try again! " << std::endl;
	}

	InitMatrixA(matrixA, n, accurancy);

	DisplayMatrix(matrixA, n);
	std::cout << std::endl;

	double ** matrixB = AllocateMemory(n);

	InitMatrixB(matrixB, n);

	std::cout << std::endl;
	DisplayMatrix(matrixA, n);
	std::cout << std::endl;

	FreeMemory(matrixA, n);
	FreeMemory(matrixB, n);

	system("pause");
	return 0;
}

