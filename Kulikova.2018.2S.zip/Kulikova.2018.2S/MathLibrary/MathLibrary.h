#pragma once

#ifdef MathLibrary_EXPORTS
#define MATHLIBRARY_API __declspec(dllexport) 
#else
#define MATHLIBRARY_API __declspec(dllimport) 
#endif

namespace Math
{
	MATHLIBRARY_API int * AllocateMemory(int);
	MATHLIBRARY_API void InitArray(int * const, int);
	MATHLIBRARY_API void DisplayArray(int * const, int);
	MATHLIBRARY_API int FindMinElement(int * const, int);
	MATHLIBRARY_API void RemoveElement(int * const, int&, int);
	MATHLIBRARY_API void CreateNewArray(int * const, int&, int * const, int&, int);
	MATHLIBRARY_API void FreeMemory(int * const);
	MATHLIBRARY_API int BinaryRepresentation(int);
	MATHLIBRARY_API void Swap(int&, int&);
	MATHLIBRARY_API void BubbleSort(int * const, int);
}
