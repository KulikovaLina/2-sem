#include "stdafx.h"
#include "CppUnitTest.h"
#include "MathLibrary.h"
#include <iostream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace MathLibraryTests
{		
	TEST_CLASS(MathExtentionTests)
	{
	public:
		
		TEST_METHOD(FindMinElement_1)
		{
			int const N = 5;
			int n = 5;
			int array[N] = { -4, 89, 0, -3, 10 };
			int expected = -4;
			
			int actual = Math::FindMinElement(array, n);

			Assert::AreEqual(expected, actual, L"Test failed");
		}

		TEST_METHOD(BinaryRepresentation_1)
		{
			int value = 19;
			int expected = 3;

			int actual = Math::BinaryRepresentation(value);

			Assert::AreEqual(expected, actual, L"Test failed");
		}

		TEST_METHOD(Swap_1)
		{
			int a = 5, b = 10;
			int expectedA = 10;
			int expectedB = 5;

			Math::Swap(a, b);

			Assert::AreEqual(b, expectedB, L"Test failed");
			Assert::AreEqual(a, expectedA, L"Test failed");
		}
	};
}